//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MySimpleFTP.rc
//
#define IDR_MENU1                       101
#define IDC_LIST1                       1000
#define IDC_EDIT1                       1001
#define IDC_EDIT2                       1002
#define IDC_BUTTON1                     1004
#define IDC_BUTTON2                     1005
#define IDC_EDIT3                       1006
#define IDC_EDIT4                       1007
#define IDC_BUTTON3                     1008
#define ID_DELETE                       40013
#define ID_EXIT                         40022
#define ID_SERVERLIST                   40023
#define ID_DOWNLOADFROMSERVER           40024
#define ID_UPLOADTOSERVER               40025
#define ID_DELETESELECTEDFILE           40026
#define HELP                            40028
#define ID_READSELECTEDFILE             40029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40030
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
